"""
Numba-compiled solve kernels (optional fast path).

The hot FLOPs of every GABES scheme flow through a handful of batched
tiny-matrix linear solves (M = n_levels² ≤ ~36 for the dense-batch schemes).
At that size the per-call LAPACK overhead dominates `np.linalg.solve`, the
NumPy expression tree allocates large (batch, M, M) temporaries, and the GIL
serialises everything around the solve. These kernels fuse the whole
per-grid-point pipeline (assemble → factor → solve → contract) into one
GIL-free parallel loop with hand-rolled complex LU.

Numba is an optional dependency: if it is missing (or GABES_DISABLE_NUMBA is
set) callers fall back to the NumPy path, so results never depend on it being
installed — only the speed does.

Numerical compatibility: the LU uses LAPACK's zgetf2 pivot rule
(max |Re| + |Im|) and the same right-looking update order, so pivot choices
match `np.linalg.solve` and results agree to ~1e-13 relative (well inside the
1e-9 regression tolerance).
"""
import cmath
import math
import os

import numpy as np

from . import core                                      # hermitian_basis (real frame)

try:                                                    # pragma: no cover
    if os.environ.get("GABES_DISABLE_NUMBA"):
        raise ImportError("disabled via GABES_DISABLE_NUMBA")
    from numba import njit, prange
    NUMBA_AVAILABLE = True
except ImportError:                                     # pragma: no cover
    NUMBA_AVAILABLE = False

    def njit(*args, **kwargs):                          # no-op decorator stub
        def wrap(fn):
            return fn
        if args and callable(args[0]):
            return args[0]
        return wrap

    prange = range


def available():
    """True if the compiled fast path can be used."""
    return NUMBA_AVAILABLE


@njit(cache=True)
def _lu_factor(A, piv):
    """In-place LU with partial pivoting (LAPACK zgetf2 conventions).

    Pivot magnitude is |Re|+|Im| (LAPACK's cabs1) so pivot choices — and hence
    rounding — track `np.linalg.solve` on the same matrix.
    """
    n = A.shape[0]
    for k in range(n):
        p = k
        amax = abs(A[k, k].real) + abs(A[k, k].imag)
        for i in range(k + 1, n):
            a = abs(A[i, k].real) + abs(A[i, k].imag)
            if a > amax:
                amax = a
                p = i
        piv[k] = p
        if p != k:
            for j in range(n):
                tmp = A[k, j]
                A[k, j] = A[p, j]
                A[p, j] = tmp
        inv = 1.0 / A[k, k]
        for i in range(k + 1, n):
            lik = A[i, k] * inv
            A[i, k] = lik
            for j in range(k + 1, n):
                A[i, j] -= lik * A[k, j]


@njit(cache=True)
def _lu_solve(A, piv, B):
    """Solve A X = B in place for B (M, K) using a factored (A, piv)."""
    n = A.shape[0]
    K = B.shape[1]
    for k in range(n):
        p = piv[k]
        if p != k:
            for j in range(K):
                tmp = B[k, j]
                B[k, j] = B[p, j]
                B[p, j] = tmp
    for i in range(1, n):                       # L y = P b (unit lower)
        for k in range(i):
            lik = A[i, k]
            for j in range(K):
                B[i, j] -= lik * B[k, j]
    for i in range(n - 1, -1, -1):              # U x = y
        for k in range(i + 1, n):
            uik = A[i, k]
            for j in range(K):
                B[i, j] -= uik * B[k, j]
        inv = 1.0 / A[i, i]
        for j in range(K):
            B[i, j] *= inv


@njit(cache=True)
def _lu_factor_real(A, piv):
    """Real in-place LU with partial pivoting (LAPACK dgetf2 conventions).

    The real-arithmetic twin of `_lu_factor`, used by the steady-state kernels
    that run in the Hermitian-generator basis (`core.hermitian_basis`), where the
    Liouvillian is real. Pivot magnitude is |A| (LAPACK's idamax) so pivots — and
    rounding — track `np.linalg.solve` on the same real matrix.
    """
    n = A.shape[0]
    for k in range(n):
        p = k
        amax = abs(A[k, k])
        for i in range(k + 1, n):
            a = abs(A[i, k])
            if a > amax:
                amax = a
                p = i
        piv[k] = p
        if p != k:
            for j in range(n):
                tmp = A[k, j]
                A[k, j] = A[p, j]
                A[p, j] = tmp
        inv = 1.0 / A[k, k]
        for i in range(k + 1, n):
            lik = A[i, k] * inv
            A[i, k] = lik
            for j in range(k + 1, n):
                A[i, j] -= lik * A[k, j]


@njit(cache=True)
def _lu_solve_real(A, piv, B):
    """Solve A X = B in place for real B (M, K) using a factored (A, piv)."""
    n = A.shape[0]
    K = B.shape[1]
    for k in range(n):
        p = piv[k]
        if p != k:
            for j in range(K):
                tmp = B[k, j]
                B[k, j] = B[p, j]
                B[p, j] = tmp
    for i in range(1, n):                       # L y = P b (unit lower)
        for k in range(i):
            lik = A[i, k]
            for j in range(K):
                B[i, j] -= lik * B[k, j]
    for i in range(n - 1, -1, -1):              # U x = y
        for k in range(i + 1, n):
            uik = A[i, k]
            for j in range(K):
                B[i, j] -= uik * B[k, j]
        inv = 1.0 / A[i, i]
        for j in range(K):
            B[i, j] *= inv


def floquet_chi_grid(L0_base, C_delta, S_v, Cp, Cm, delta_axis, deff_axis,
                     omega_hf, branch, w_probe, w_conj, n_levels, n_f=1):
    """Finite-Floquet grid with an exact, guarded Hermitian-basis reduction.

    The physical affine coefficients must preserve Hermiticity and the two
    couplings must be adjoint partners. Check these identities in raw vec
    coordinates, without a tolerance that could discard a physical term.
    Otherwise retain the general two-chain solver, including complex axes.

    This changes neither n_f nor the velocity/detuning grid. The full adjacent-
    order convergence audit in the caller remains independent and unchanged.
    """
    M = n_levels * n_levels
    perm = core._transpose_perm(n_levels)
    coefficients = tuple(np.asarray(a) for a in (L0_base, C_delta, S_v))
    cp, cm = np.asarray(Cp), np.asarray(Cm)
    real_axes = all(np.isrealobj(a) and np.isfinite(a).all()
                    for a in (delta_axis, deff_axis, omega_hf, branch))
    symmetric = (real_axes and all(a.shape == (M, M) and
        np.array_equal(a, a.conj()[perm][:, perm]) for a in coefficients)
        and cp.shape == cm.shape == (M, M)
        and np.array_equal(cm, cp.conj()[perm][:, perm]))
    if not symmetric:
        return _floquet_chi_grid_general(
            L0_base, C_delta, S_v, Cp, Cm, delta_axis, deff_axis,
            omega_hf, branch, w_probe, w_conj, n_levels, n_f)

    U = core.hermitian_basis(n_levels)
    Uh = U.conj().T
    # The checked raw identities imply real coefficients in this basis;
    # imaginary transform roundoff is not a physical approximation.
    real_coefficients = [np.ascontiguousarray((Uh @ a @ U).real)
                         for a in coefficients]
    return _floquet_chi_grid_hermitian(
        *real_coefficients, np.ascontiguousarray(Uh @ cp @ U),
        np.ascontiguousarray(delta_axis, dtype=np.float64),
        np.ascontiguousarray(deff_axis, dtype=np.float64),
        float(omega_hf), float(branch),
        np.ascontiguousarray(np.asarray(w_probe) @ U),
        np.ascontiguousarray(np.asarray(w_conj) @ U), n_levels, n_f)


@njit(cache=True, parallel=True)
def _floquet_chi_grid_hermitian(L0_base, C_delta, S_v, Cp, delta_axis,
                               deff_axis, omega_hf, branch, w_probe, w_conj,
                               n_levels, n_f):
    """One complex harmonic chain and one real trace-one solve per grid point."""
    if n_f < 1:
        raise ValueError("n_f must be at least 1")
    M = n_levels * n_levels
    probe = np.empty((delta_axis.size, deff_axis.size), np.complex128)
    conjugate = np.empty_like(probe)
    for i in prange(delta_axis.size):
        delta = delta_axis[i]
        ob = omega_hf + branch * delta
        L = np.empty((M, M), np.float64)
        A = np.empty((M, M), np.complex128)
        R = np.empty((M, M), np.complex128)
        rhs_matrix = np.empty((M, M), np.complex128)
        Aeff = np.empty((M, M), np.float64)
        rhs = np.empty((M, 1), np.float64)
        piv = np.empty(M, np.int64)
        for j in range(deff_axis.size):
            for r in range(M):
                for col in range(M):
                    L[r, col] = (L0_base[r, col] + delta*C_delta[r, col]
                                 - deff_axis[j]*S_v[r, col])

            # MATHEMATICALLY EXACT for every symmetric finite cutoff: with
            # real L and C-=C+*, induction from R_(nf+1)=Q_(-nf-1)=0 gives
            # Q_(-h)=R_h*. No negative-chain LU adds rigor under this guard.
            # Proof + independent two-chain/dense tests: docs/ultra_performance.md.
            for harmonic in range(n_f, 0, -1):
                for r in range(M):
                    for col in range(M):
                        value = L[r, col] + 0j
                        if r == col:
                            value += 1j*harmonic*ob
                        if harmonic < n_f:
                            for k in range(M):
                                value += np.conj(Cp[r, k])*R[k, col]
                        A[r, col] = value
                        rhs_matrix[r, col] = Cp[r, col]
                _lu_factor(A, piv)
                _lu_solve(A, piv, rhs_matrix)
                for r in range(M):
                    for col in range(M):
                        R[r, col] = -rhs_matrix[r, col]

            # L_eff = L + C+ R1* + C- R1 = L + 2 Re(C- R1).
            # The first n Hermitian basis vectors are population projectors,
            # so replacing row 0 by their sum is the same trace constraint.
            for r in range(M):
                for col in range(M):
                    feedback = 0.0
                    for k in range(M):
                        feedback += (Cp[r, k].real*R[k, col].real
                                     + Cp[r, k].imag*R[k, col].imag)
                    Aeff[r, col] = L[r, col] + 2.0*feedback
            for col in range(M):
                Aeff[0, col] = 1.0 if col < n_levels else 0.0
            for r in range(M):
                rhs[r, 0] = 0.0
            rhs[0, 0] = 1.0
            _lu_factor_real(Aeff, piv)
            _lu_solve_real(Aeff, piv, rhs)

            probe_value = 0.0 + 0.0j
            conj_value = 0.0 + 0.0j
            for r in range(M):
                probe_value += w_probe[r]*rhs[r, 0]
                rho1 = 0.0 + 0.0j
                for k in range(M):
                    rho1 += R[r, k]*rhs[k, 0]
                conj_value += w_conj[r]*rho1
            probe[i, j] = probe_value
            conjugate[i, j] = conj_value
    return probe, conjugate


@njit(cache=True, parallel=True)
def _floquet_chi_grid_general(L0_base, C_delta, S_v, Cp, Cm, delta_axis, deff_axis,
                              omega_hf, branch, w_probe, w_conj, n_levels, n_f=1):
    """
    Fused finite-Floquet FWM χ-bar grid for ``-n_f,...,+n_f``.

    Equivalent to the `chi_matrix_table` δ-loop over `core.floquet_solve`,
    using the affine structure of the Hamiltonian:

        L0(δ, Δ_eff) = L0_base + δ·C_delta − Δ_eff·S_v
        Ω_beat(δ)    = omega_hf + branch·δ

    Positive and negative chains are eliminated by the same block continued
    fraction as :func:`gabes.core.floquet_solve_truncated`.  The implementation
    keeps only ``2*n_f`` M-by-M recurrence blocks and never assembles the dense
    extended Liouvillian.  After solving the trace-one zero harmonic it backs
    out rho_(+1) and contracts the two requested polarizations:

        chi_probe[i, j] = Σ_k w_probe[k]·ρ₀[k]
        chi_conj[i, j]  = Σ_k w_conj[k]·ρ₊₁[k]

    Workspaces are hoisted per delta row (one prange task), so the inner
    Delta_eff loop runs allocation-free. ``n_f=1`` remains API-compatible with
    the former three-mode kernel.
    """
    if n_f < 1:
        raise ValueError("n_f must be at least 1")
    n_d = delta_axis.size
    n_de = deff_axis.size
    M = n_levels * n_levels
    chi_probe = np.empty((n_d, n_de), np.complex128)
    chi_conj = np.empty((n_d, n_de), np.complex128)

    for i in prange(n_d):
        delta = delta_axis[i]
        ob = omega_hf + branch * delta
        A = np.empty((M, M), np.complex128)
        Aeff = np.empty((M, M), np.complex128)
        rhs_matrix = np.empty((M, M), np.complex128)
        Rchain = np.empty((n_f, M, M), np.complex128)
        Qchain = np.empty((n_f, M, M), np.complex128)
        rhs = np.empty((M, 1), np.complex128)
        rho1 = np.empty(M, np.complex128)
        piv = np.empty(M, np.int64)

        for j in range(n_de):
            deff = deff_axis[j]
            for r in range(M):
                for c in range(M):
                    l0 = L0_base[r, c] + delta * C_delta[r, c] - deff * S_v[r, c]
                    Aeff[r, c] = l0

            # Positive chain: R_h maps rho_(h-1) -> rho_h.
            for harmonic in range(n_f, 0, -1):
                idx = harmonic - 1
                for r in range(M):
                    for c in range(M):
                        value = (L0_base[r, c] + delta * C_delta[r, c]
                                 - deff * S_v[r, c])
                        if r == c:
                            value += 1j * harmonic * ob
                        if harmonic < n_f:
                            feedback = 0.0 + 0.0j
                            for k in range(M):
                                feedback += Cm[r, k] * Rchain[idx + 1, k, c]
                            value += feedback
                        A[r, c] = value
                        rhs_matrix[r, c] = Cp[r, c]
                _lu_factor(A, piv)
                _lu_solve(A, piv, rhs_matrix)
                for r in range(M):
                    for c in range(M):
                        Rchain[idx, r, c] = -rhs_matrix[r, c]

            # Negative chain: Q_h maps rho_(h+1) -> rho_h.
            for harmonic in range(-n_f, 0):
                idx = harmonic + n_f
                for r in range(M):
                    for c in range(M):
                        value = (L0_base[r, c] + delta * C_delta[r, c]
                                 - deff * S_v[r, c])
                        if r == c:
                            value += 1j * harmonic * ob
                        if harmonic > -n_f:
                            feedback = 0.0 + 0.0j
                            for k in range(M):
                                feedback += Cp[r, k] * Qchain[idx - 1, k, c]
                            value += feedback
                        A[r, c] = value
                        rhs_matrix[r, c] = Cm[r, c]
                _lu_factor(A, piv)
                _lu_solve(A, piv, rhs_matrix)
                for r in range(M):
                    for c in range(M):
                        Qchain[idx, r, c] = -rhs_matrix[r, c]

            # Effective zero-harmonic block L0 + Cp Q_-1 + Cm R_+1.
            for r in range(M):
                for c in range(M):
                    feedback = 0.0 + 0.0j
                    for k in range(M):
                        feedback += (Cp[r, k] * Qchain[n_f - 1, k, c]
                                     + Cm[r, k] * Rchain[0, k, c])
                    Aeff[r, c] += feedback

            for c in range(M):                      # trace-normalisation row 0
                Aeff[0, c] = 0.0
            for s in range(n_levels):
                Aeff[0, s * n_levels + s] = 1.0
            for r in range(M):
                rhs[r, 0] = 0.0
            rhs[0, 0] = 1.0

            _lu_factor(Aeff, piv)
            _lu_solve(Aeff, piv, rhs)               # rhs = ρ₀

            for r in range(M):                      # rho_+1 = R_1 rho_0
                acc = 0.0 + 0.0j
                for k in range(M):
                    acc += Rchain[0, r, k] * rhs[k, 0]
                rho1[r] = acc

            cp_acc = 0.0 + 0.0j
            cc_acc = 0.0 + 0.0j
            for k in range(M):
                cp_acc += w_probe[k] * rhs[k, 0]
                cc_acc += w_conj[k] * rho1[k]
            chi_probe[i, j] = cp_acc
            chi_conj[i, j] = cc_acc

    return chi_probe, chi_conj


@njit(cache=True, parallel=True)
def _magneto_buffer_grid_real(L0_all, deff, S_v, n_levels):
    """Real-frame single-region magneto (B, v) grid; see `magneto_buffer_grid`.

    Inputs are real (Hermitian-generator basis); the trace row is Σ_{s<n} r_s = 1.
    Returns the real coordinate vectors r, shape (nB, nv, M).
    """
    nB = L0_all.shape[0]
    nv = deff.size
    M = n_levels * n_levels
    out = np.empty((nB, nv, M), np.float64)
    for b in prange(nB):
        A = np.empty((M, M), np.float64)
        rhs = np.empty((M, 1), np.float64)
        piv = np.empty(M, np.int64)
        for j in range(nv):
            d = deff[j]
            for r in range(M):
                for c in range(M):
                    A[r, c] = L0_all[b, r, c] - d * S_v[r, c]
            for c in range(M):
                A[0, c] = 0.0
            for s in range(n_levels):
                A[0, s] = 1.0
            for r in range(M):
                rhs[r, 0] = 0.0
            rhs[0, 0] = 1.0
            _lu_factor_real(A, piv)
            _lu_solve_real(A, piv, rhs)
            for r in range(M):
                out[b, j, r] = rhs[r, 0]
    return out


def magneto_buffer_grid(L0_all, deff, S_v, n_levels):
    """
    Single-region magneto steady state over the (B, v) grid (the buffer-cell
    path). Mirrors `core.steady_state_from_liouvillian` on
    A = L0_all[b] − deff[j]·S_v with the trace row replaced, parallel over B.

    L0_all and S_v are Hermiticity-preserving, so they are changed once into the
    real Hermitian-generator basis (`core.hermitian_basis`) and the (B × v) grid
    is solved in real arithmetic (~2–4× fewer flops); ρ is reconstructed as
    vec(ρ) = U·r. Returns ρ as (nB, nv, n_levels, n_levels).
    """
    nB = L0_all.shape[0]
    nv = int(np.asarray(deff).size)
    U = core.hermitian_basis(n_levels)
    Uh = U.conj().T
    L0_r = np.ascontiguousarray(np.real(Uh @ L0_all @ U))   # batched BLAS matmul
    S_vr = np.ascontiguousarray(np.real(Uh @ S_v @ U))
    r = _magneto_buffer_grid_real(
        L0_r, np.ascontiguousarray(deff, dtype=np.float64), S_vr, n_levels)
    rho_vec = r @ U.T                                       # real r → complex vec(ρ)
    return rho_vec.reshape(nB, nv, n_levels, n_levels)


@njit(cache=True, parallel=True)
def _magneto_two_region_grid_real(L_light0, L_dark0, deff, S_v,
                                  gamma_out, gamma_in, n_levels):
    """Real-frame two-region magneto (B, v) grid; see `magneto_two_region_grid`.

    Inputs are real (each n-level block in the Hermitian-generator basis); the γ
    exchange is ∝ I (basis-invariant) and the trace row is the two-region
    population sum Σ_{s<n} (r_light[s] + r_dark[s]) = 1. Returns the real
    light-block coordinate vectors, shape (nB, nv, M).
    """
    nB = L_light0.shape[0]
    nv = deff.size
    M = n_levels * n_levels
    M2 = 2 * M
    out = np.empty((nB, nv, M), np.float64)
    for b in prange(nB):
        A = np.zeros((M2, M2), np.float64)           # reused across the v loop
        rhs = np.zeros((M2, 1), np.float64)
        piv = np.empty(M2, np.int64)
        for j in range(nv):
            d = deff[j]
            for r in range(M):
                for c in range(M):
                    A[r, c] = L_light0[b, r, c] - d * S_v[r, c]
                    A[r, M + c] = 0.0
                    A[M + r, c] = 0.0
                    A[M + r, M + c] = L_dark0[b, r, c]
                A[r, r] -= gamma_out
                A[r, M + r] += gamma_in
                A[M + r, r] += gamma_out
                A[M + r, M + r] -= gamma_in
            for c in range(M2):                      # global trace row
                A[0, c] = 0.0
            for s in range(n_levels):                # populations = first n coords
                A[0, s] = 1.0
                A[0, M + s] = 1.0
            for r in range(M2):                      # reset RHS (solved in place)
                rhs[r, 0] = 0.0
            rhs[0, 0] = 1.0
            _lu_factor_real(A, piv)
            _lu_solve_real(A, piv, rhs)              # rhs now holds the solution
            for r in range(M):                       # light block only
                out[b, j, r] = rhs[r, 0]
    return out


def magneto_two_region_grid(L_light0, L_dark0, deff, S_v,
                            gamma_out, gamma_in, n_levels):
    """
    Two-region (light/dark) magneto steady state over the (B, v) grid (the
    paraffin-cell path). Builds the 2M×2M exchange system

        [ L_light − Δ_eff·S_v − γ_out·I        γ_in·I            ]
        [        γ_out·I                  L_dark − γ_in·I         ]

    (only the light block carries the optical Δ_eff shift), replaces the global
    trace row with the two-region population sum, solves, and returns the in-beam
    light block ρ_light as (nB, nv, n_levels, n_levels).

    The hot path: at 2M up to ~200 the (nB,nv,2M,2M) solve dominates. Each block
    is Hermiticity-preserving and the γ exchange is ∝ I (basis-invariant), so the
    system is changed once into the real Hermitian-generator basis
    (`core.hermitian_basis`) and solved in real arithmetic (~2–4× fewer flops,
    half the memory); ρ_light is reconstructed as vec(ρ) = U·r_light. Pin BLAS to
    one thread around the call so the prange threads don't oversubscribe.
    """
    nB = L_light0.shape[0]
    nv = int(np.asarray(deff).size)
    U = core.hermitian_basis(n_levels)
    Uh = U.conj().T
    L_light_r = np.ascontiguousarray(np.real(Uh @ L_light0 @ U))   # batched BLAS
    L_dark_r = np.ascontiguousarray(np.real(Uh @ L_dark0 @ U))
    S_vr = np.ascontiguousarray(np.real(Uh @ S_v @ U))
    r = _magneto_two_region_grid_real(
        L_light_r, L_dark_r, np.ascontiguousarray(deff, dtype=np.float64),
        S_vr, float(gamma_out), float(gamma_in), n_levels)
    rho_vec = r @ U.T                                              # real → vec(ρ)
    return rho_vec.reshape(nB, nv, n_levels, n_levels)


@njit(cache=True, parallel=True)
def _affine_scan_chi_real(base, A_coef, B_coef, scan, kv, weights, w_coh, n_levels):
    """Real-arithmetic core of `affine_scan_chi` (see it for the physics).

    `base, A_coef, B_coef` are the REAL Hermitian-generator-basis coefficient
    matrices; `w_coh` (complex, length M) reconstructs the target coherence from
    the real coordinate vector r as ρ[coh] = Σ_a w_coh[a]·r_a. The trace row is
    Σ_{s<n} r_s = 1 (populations are the first n real coordinates).
    """
    ns = scan.size
    nv = kv.size
    M = n_levels * n_levels
    out = np.empty(ns, np.complex128)
    for i in prange(ns):
        s = scan[i]
        A = np.empty((M, M), np.float64)
        rhs = np.empty((M, 1), np.float64)
        piv = np.empty(M, np.int64)
        acc = 0.0 + 0.0j
        for j in range(nv):
            kvj = kv[j]
            for r in range(M):
                for c in range(M):
                    A[r, c] = base[r, c] + s * A_coef[r, c] + kvj * B_coef[r, c]
            for c in range(M):
                A[0, c] = 0.0
            for st in range(n_levels):
                A[0, st] = 1.0                  # trace: populations = first n coords
            for r in range(M):
                rhs[r, 0] = 0.0
            rhs[0, 0] = 1.0
            _lu_factor_real(A, piv)
            _lu_solve_real(A, piv, rhs)
            coh = 0.0 + 0.0j
            for a in range(M):
                coh += w_coh[a] * rhs[a, 0]
            acc += weights[j] * coh
        out[i] = acc
    return out


def affine_scan_chi(base, A_coef, B_coef, scan, kv, weights, coh_idx, n_levels):
    """
    One probe coherence χ̄(scan) = Σ_v weights[v]·ρ[coh] / (caller's Ω), for a
    Hamiltonian that is affine in the scan variable s (Λ EIT/AT/CPT, Rydberg).

    The per-(s, v) Liouvillian is assembled from three constant matrices:

        L(s, kv) = base + s·A_coef + kv·B_coef

    where (computed once by the caller from two `build_liouvillian` evaluations)

        base    = L₀(s=0)                          [Lindblad already folded in]
        A_coef  = dL/ds − S_v                      [scan shift + two-photon term]
        B_coef  = S_v                              [optical Doppler shift, k·v]

    This collapses the scheme's Python `for s in scan` loop (rebuilding a
    Liouvillian and solving a velocity batch each step) into one parallel pass:
    prange over the scan, an allocation-free inner velocity loop, trace-row
    normalisation, hand-rolled LU, and the velocity-weighted contraction of the
    coherence at flat index `coh_idx = e·n_levels + g`.

    The three constant matrices are Hermiticity-preserving, so they are changed
    once into the real Hermitian-generator basis (`core.hermitian_basis`) and the
    whole scan is solved in real arithmetic (~2–4× fewer flops, half the memory);
    ρ[coh] is reconstructed from the row `U[coh_idx]`. Bit-for-bit the same χ̄ as
    the complex form to machine precision. Covers all three cases identically:
      Λ Doppler-on   : kv = k·v (Maxwell grid),  weights = Maxwell weights
      Λ Doppler-off  : kv = [0],                 weights = [1]
      Rydberg        : kv = [0], B_coef = S_v = 0 (no Doppler), weights = [1]
    """
    U = core.hermitian_basis(n_levels)
    Uh = U.conj().T
    base_r = np.ascontiguousarray(np.real(Uh @ base @ U))
    A_coef_r = np.ascontiguousarray(np.real(Uh @ A_coef @ U))
    B_coef_r = np.ascontiguousarray(np.real(Uh @ B_coef @ U))
    w_coh = np.ascontiguousarray(U[coh_idx])
    return _affine_scan_chi_real(
        base_r, A_coef_r, B_coef_r,
        np.ascontiguousarray(scan, dtype=np.float64),
        np.ascontiguousarray(kv, dtype=np.float64),
        np.ascontiguousarray(weights, dtype=np.float64),
        w_coh, n_levels)


# ---------------------------------------------------------------------------
# Pole–residue Doppler reduction (see gabes/pole_doppler.py for the algebra).
# The eigenproblem stays in LAPACK via NumPy; these stages are the O(rows·n³)
# bookkeeping around it and remain cacheable (no ctypes pointers).
# ---------------------------------------------------------------------------
@njit(cache=True, parallel=True)
def pole_schur_rows(NN0, NN1, NR0, NR1, RN0, RN1, RR0, RR1, S_RR_inv,
                    eN, eR, WR, WN, t):
    """Per row: Z = S_RR⁻¹(A_RR − A_RN A_NN⁻¹ A_NR), g, readout constants.

    Returns ``Z`` (rows, nR, nR), ``g = S_RR⁻¹(A_RN y − e_R)`` (rows, nR),
    ``c0 = W_N y`` (rows, n_readouts) and ``weff = W_R − W_N A_NN⁻¹ A_NR``
    (rows, n_readouts, nR), with ``y = A_NN⁻¹ e_N``.
    """
    n_rows = t.size
    nN = NN0.shape[0]
    nR = RR0.shape[0]
    n_ro = WR.shape[0]
    Z = np.empty((n_rows, nR, nR), np.float64)
    g = np.empty((n_rows, nR), np.float64)
    c0 = np.empty((n_rows, n_ro), np.complex128)
    weff = np.empty((n_rows, n_ro, nR), np.complex128)
    for i in prange(n_rows):
        ti = t[i]
        A = np.empty((nN, nN), np.float64)
        B = np.empty((nN, nR + 1), np.float64)
        RN = np.empty((nR, nN), np.float64)
        K = np.empty((nR, nR), np.float64)
        u = np.empty(nR, np.float64)
        piv = np.empty(nN, np.int64)
        for a in range(nN):
            for b in range(nN):
                A[a, b] = NN0[a, b] + ti * NN1[a, b]
            for b in range(nR):
                B[a, b] = NR0[a, b] + ti * NR1[a, b]
            B[a, nR] = eN[a]
        for a in range(nR):
            for b in range(nN):
                RN[a, b] = RN0[a, b] + ti * RN1[a, b]
        _lu_factor_real(A, piv)
        _lu_solve_real(A, piv, B)                 # B = [A_NN⁻¹ A_NR | y]
        for a in range(nR):
            for b in range(nR):
                acc = RR0[a, b] + ti * RR1[a, b]
                for k in range(nN):
                    acc -= RN[a, k] * B[k, b]
                K[a, b] = acc
            acc = -eR[a]
            for k in range(nN):
                acc += RN[a, k] * B[k, nR]
            u[a] = acc
        for a in range(nR):
            for b in range(nR):
                acc = 0.0
                for k in range(nR):
                    acc += S_RR_inv[a, k] * K[k, b]
                Z[i, a, b] = acc
            acc = 0.0
            for k in range(nR):
                acc += S_RR_inv[a, k] * u[k]
            g[i, a] = acc
        for r in range(n_ro):
            acc_c = 0.0 + 0.0j
            for k in range(nN):
                acc_c += WN[r, k] * B[k, nR]
            c0[i, r] = acc_c
            for b in range(nR):
                acc_c = WR[r, b]
                for k in range(nN):
                    acc_c -= WN[r, k] * B[k, b]
                weff[i, r, b] = acc_c
    return Z, g, c0, weff


@njit(cache=True, parallel=True)
def pole_residue_rows(V, g, weff):
    """Residues ``res[i, r, k] = (weff V)[i, r, k] · (V⁻¹ g)[i, k]``."""
    n_rows, nR, _ = V.shape
    n_ro = weff.shape[1]
    res = np.empty((n_rows, n_ro, nR), np.complex128)
    for i in prange(n_rows):
        A = np.empty((nR, nR), np.complex128)
        rhs = np.empty((nR, 1), np.complex128)
        piv = np.empty(nR, np.int64)
        for a in range(nR):
            for c in range(nR):
                A[a, c] = V[i, a, c]
            rhs[a, 0] = g[i, a]
        _lu_factor(A, piv)
        _lu_solve(A, piv, rhs)
        for r in range(n_ro):
            for k in range(nR):
                acc = 0.0 + 0.0j
                for a in range(nR):
                    acc += weff[i, r, a] * V[i, a, k]
                res[i, r, k] = acc * rhs[k, 0]
    return res


@njit(cache=True, parallel=True)
def pole_discrete_mean(lam, res, c0, nodes, weights):
    """``Σ_j w_j [c0 − Σ_k res_k / (lam_k − D_j)]`` per row, in real arithmetic."""
    n_rows, n_ro, nR = res.shape
    nv = nodes.size
    wsum = 0.0
    for j in range(nv):
        wsum += weights[j]
    out = np.empty((n_rows, n_ro), np.complex128)
    for i in prange(n_rows):
        s = np.empty(nR, np.complex128)
        for k in range(nR):
            lr = lam[i, k].real
            li = lam[i, k].imag
            acc_r = 0.0
            acc_i = 0.0
            for j in range(nv):
                dr = lr - nodes[j]
                scale = weights[j] / (dr * dr + li * li)
                acc_r += dr * scale
                acc_i -= li * scale
            s[k] = acc_r + 1j * acc_i
        for r in range(n_ro):
            acc = c0[i, r] * wsum
            for k in range(nR):
                acc -= res[i, r, k] * s[k]
            out[i, r] = acc
    return out


@njit(cache=True, parallel=True)
def segmented_depletion_gain(M, dz, profile, P_pump, P_seed,
                             conjugate_power_ratio, clamp):
    """Row-parallel G_s, G_c of ``fwm._ultra_segmented_gain``.

    Same recurrence: per segment, scale the off-diagonal Maxwell couplings by
    ``profile[s]·sqrt(pump_remaining/P_pump)``, step the amplitudes with the
    closed-form 2×2 exponential of ``core.matrix_exp_2x2`` (including its
    exponent clamp), then debit the pump by the added seed and conjugate power.
    ``M`` is the (rows, 2, 2) matrix of ``observables._gain_matrix_from_chi``.
    """
    n = M.shape[0]
    nseg = profile.size
    P_ref = max(P_pump, 1e-30)
    P_norm = max(P_seed, 1e-30)
    G_s = np.empty(n, np.float64)
    G_c = np.empty(n, np.float64)
    for i in prange(n):
        a0 = math.sqrt(P_norm) + 0.0j
        a1 = 0.0 + 0.0j
        remaining = P_ref
        for seg in range(nseg):
            ratio = remaining / P_ref
            if ratio < 0.0:
                ratio = 0.0
            elif ratio > 1.0:
                ratio = 1.0
            scale = profile[seg] * math.sqrt(ratio)
            m00 = M[i, 0, 0]
            m01 = M[i, 0, 1] * scale
            m10 = M[i, 1, 0] * scale
            m11 = M[i, 1, 1]
            half = 0.5 * (m00 + m11)
            q00 = m00 - half
            q11 = m11 - half
            c = cmath.sqrt(-(q00 * q11 - m01 * m10) + 0.0j)
            cL = c * dz
            sL = half * dz
            cL = min(max(cL.real, -clamp), clamp) + 1j * cL.imag
            sL = min(max(sL.real, -clamp), clamp) + 1j * sL.imag
            if abs(c) > 1e-30:
                sinh_over_c = cmath.sinh(cL) / c
            else:
                sinh_over_c = dz + 0.0j
            cosh_cL = cmath.cosh(cL)
            exp_sL = cmath.exp(sL)
            t00 = exp_sL * (cosh_cL + sinh_over_c * q00)
            t01 = exp_sL * (sinh_over_c * m01)
            t10 = exp_sL * (sinh_over_c * m10)
            t11 = exp_sL * (cosh_cL + sinh_over_c * q11)
            b0 = t00 * a0 + t01 * a1
            b1 = t10 * a0 + t11 * a1
            a0 = b0
            a1 = b1
            seed_added = max(abs(a0) ** 2 - P_seed, 0.0)
            conj_power = max(abs(a1) ** 2 * conjugate_power_ratio, 0.0)
            remaining = max(P_pump - seed_added - conj_power, 0.0)
        G_s[i] = abs(a0) ** 2 / P_norm
        G_c[i] = abs(a1) ** 2 / P_norm
    return G_s, G_c
